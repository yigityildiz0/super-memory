# Host execution adapter

This complete edition is generated only from the canonical master. Preserve the
source's workflow, licenses, explicit activation gates and authorization rules.
The original SKILL.md is retained in source-SKILL.md for provenance, not as a
second auto-discovered skill. Edit the canonical master or generators only.

- Use the live tool catalog. Examples named Read/Write/Bash/Task, web.run,
  functions.*, MCP, or another host's tool names are intent, not available APIs.
- Resolve scripts/references from this skill's actual root, and module-relative
  paths from the module directory. Personal absolute paths in preserved examples
  are examples only: discover the user's workspace, home and shell first.
- Browser/desktop/UI automation requires both a connected tool and user authority.
  No screenshot access, operating-system control, API key, account entitlement,
  plugin activation, GPU, paid quota or network access is created by this package.
- Web/mobile containers cannot be assumed to access local Windows files. Ask for
  the needed input or report the missing capability; never claim an action ran.
- Preserve explicit-only Caveman activation and every source capability.
- Apply the user's no-extra-cost profile to the complete module tree: use this
  host's existing session/tools, public sources and local computation. Never
  fall back to separately billed APIs, cloud jobs, credits or paid trials.
  A saved key or configured connector does not change this choice. Preserved
  provider examples are references; use a free/local equivalent or disclose
  the unavailable capability. Gemini Deep Research is removed from this set.
- Do not auto-enable tools, alter sandbox/configuration, install dependencies or
  delegate merely because an upstream example does so. Respect session policy.
- Local files and cloud/account skills are separate. Select one active source per
  skill if duplicates appear; preserve existing user enable/disable preferences.

## GPT / Codex execution environment

Use only search, browser, connector and file tools exposed in the active session.
Inspect live capabilities before selecting a provider; optional PubMed/Elicit/scite
tools are not mandatory dependencies. Follow the host's tool instructions and
report unavailable network/full text explicitly. Packaged references are relative
to this skill; do not assume local Windows paths exist in ChatGPT web/mobile.
Local installation does not install a plugin into the user's cloud account.
